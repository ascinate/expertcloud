import React from 'react';
import ReactDOM from 'react-dom';
import { render } from 'react-dom';
import './App.css';
import ExpertCallHistory from './ExpertCall/ExpertCallHistory';
import ExpertPayment from './ExpertPayment.js/ExpertPayment';
import ExpertDashboard from './ExpertDashboard/ExpertDashboard';
import ExpertCompliance from './ExpertCompliance/ExpertCompliance';
import ExpertProjectDetails from './ExpertDashboard/ExpertProjectDetails';
import LandingRegister from './ExpertRegister/LandingRegister';
import ExpertRegister from "./ExpertRegister/ExpertRegister";
import StepFour from "./ExpertRegister/StepFour";
import ExpertLogin from "./ExpertLogin/ExpertLogin";
import { BrowserRouter as Router , Routes, Route } from "react-router-dom";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle.js";

import $ from "jquery";


function App() {
  return (
    <Router>
         

    <Routes>
        <Route exact="true" path="/expertdashboard" element={<ExpertDashboard/>} />
        <Route exact="true" path="/expertcallhistory" element={<ExpertCallHistory/>} />
        <Route exact="true" path="/expertpayment" element={<ExpertPayment/>} />
        <Route exact="true" path="/expertcompliance" element={<ExpertCompliance/>} />
        <Route exact="true" path="/expertprojectdetails" element={<ExpertProjectDetails/>} />
        <Route exact="true" path="/landingregister" element={<LandingRegister/>} />
        <Route exact="true" path="/expertregister" element={<ExpertRegister/>} />
        <Route exact="true" path="/stepfour" element={<StepFour/>} />
        <Route exact="true" path="/" element={<ExpertLogin/>} />
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    </Routes>
            
       
</Router>
  );
}

export default App;
