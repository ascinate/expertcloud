import { FaRegEnvelope } from "react-icons/fa";
import { BsCheck2Circle, BsFillCartFill, BsFillGeoAltFill } from "react-icons/bs";


const CompletesTablAllData =[

    {
        id:1,
        // icon:<FaRegEnvelope/>,
        titel:"Business analyst for developing my idea and make it live to users",
        location:"New York, USA",
        company:" Yahoo Company",
        price:"$525",
        duration:"Per hour",
        deadline:"26-04-2022",
        deadlinedays:"2",
        adddate:"28-04-2022",
        addays:"2",
    },
    {
        id:2,
        // icon:<BsCheck2Circle/>,
        titel:"Business analyst for developing my idea and make it live to users",
        location:"New York, USA",
        company:" Yahoo Company",
        price:"$525",
        duration:"Per hour",
        deadline:"26-04-2022",
        deadlinedays:"2",
        adddate:"28-04-2022",
        addays:"2",
    },
    {
        id:3,
        // icon:<BsFillCartFill/>,
        titel:"Business analyst for developing my idea and make it live to users",
        location:"New York, USA",
        company:" Yahoo Company",
        price:"$525",
        duration:"Per hour",
        deadline:"26-04-2022",
        deadlinedays:"2",
        adddate:"28-04-2022",
        addays:"2",
    },
    {
        id:4,
        titel:"Business analyst for developing my idea and make it live to users",
        location:"New York, USA",
        company:" Yahoo Company",
        price:"$525",
        duration:"Per hour",
        deadline:"26-04-2022",
        deadlinedays:"2",
        adddate:"28-04-2022",
        addays:"2",
    }
]
export default CompletesTablAllData;